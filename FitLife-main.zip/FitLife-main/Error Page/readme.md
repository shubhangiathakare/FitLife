**OPEN TO ALL. NO NEED TO CLAIM. NO SUBMISSION WILL BE ACCEPTED AFTER 5TH DEC 11.59pm.🕐**

**"Oops! The page you're looking for doesn't exist.”**

When a user encounters a 404 error, it typically means that the URL they entered or clicked on doesn't lead to an existing page on the server.❌

<aside>
💡 In this task you have to design error 404 page.✅

</aside>

Search for your own unique vector and complete the **ERROR 404** design.

You can take inspiration from the image provided below**.**

or check out this playlist:
[https://www.youtube.com/watch?v=NfkQeOSmIMY&list=PLW-zSkCnZ-gDer-VZlBbe1f9-G0zNYdtg](https://youtu.be/kvpTt52MJME?si=5akUUobvSQXgCrFK)

![op4.png](https://prod-files-secure.s3.us-west-2.amazonaws.com/fce54777-e8a0-42d6-a59f-9af34e4c1bd4/b8be7a6b-9edb-4196-923e-b8117962478c/op4.png)

## **Submission Guideline:**

- Submit the link of the Figma file in a .txt file under the "Error Page" Folder only.
- Any kind of plagiarism will not be supported. You can take inspiration, but the idea must be unique.

> This task is for 15 points.

## **MDC (Minimum Design Criteria):**

The page should look appealing and should not be exactly same as the image provided.

For any doubts related to the task or the submission process you can always ping us on discord. We will be happy to help.😊
