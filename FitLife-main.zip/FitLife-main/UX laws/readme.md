**OPEN TO ALL. NO NEEED TO CLAIM.**

**NO SUBMISSION WILL BE ACCEPTED AFTER 15TH DEC 11:59PM.**

While you are working on the best user flow for the FitLife💪 app, here is another short task to test your thinking 🤔 as User Experience Designer!.

UX laws serve as guiding principles for designers, emphasizing user-centric approaches.👀

Visit this site https://lawsofux.com/ and try to skim through some of the laws of the UX, no need to read all of them only reading few will be enough for this task.

Your task is to identify 3 such UX laws that have come into play on this https://stripe.com/en-in website. Elaborate on how the laws have been applied or are coming into play. Present your thoughts in any format that seems appropriate to you. YOU MUST include screenshots of the section where you feel the laws have been used and explain how the laws have been applied. Go be lawyers of UX!😎

## Submission Guideline:

Submit your ideas in google doc and provide the link in a txt file and place it in the ‘UX Laws’ folder.

## Minimum Design Criteria (MDC)

Pointing out 3 laws of UX that have been applied on https://stripe.com/en-in with screenshots of the section being referred to along with brief explanation of how the law has been applied in that section.🤔
